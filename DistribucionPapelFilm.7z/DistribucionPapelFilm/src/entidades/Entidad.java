package entidades;

public class Entidad
{

    private String OID;

    public Entidad ()
    {
    }

    public String getOID ()
    {
        return OID;
    }

    public void setOID (String OID)
    {
        this.OID = OID;
    }

}
